import { Writable } from "node:stream";
import { setTimeout } from "node:timers/promises";
import { Log } from "debug-level";
import { AV_NOPTS_VALUE, type Packet } from "node-av";

/*
 * Pts jumps larger than this are treated as a seek (or a timestamp wrap)
 * rather than jitter: the pacer re-anchors its timing compensation instead
 * of sleeping through the gap. Normal per-frame gaps are tens of ms.
 */
const SEEK_JUMP_THRESHOLD_MS = 1000;

/*
 * Sync gaps larger than this can never be closed by waiting in real time
 * (it would take `delta`ms): instead of waiting up to it per frame, a gap
 * this wide means the other stream's timestamps have moved away wholesale
 * (e.g. it was seeked and is still draining stale content), so this stream
 * races instead. Normal per-frame gaps stay well below this.
 */
const MAX_SYNC_WAIT_MS = 3000;

export class BaseMediaStream extends Writable {
  private _pts?: number;
  private _syncTolerance = 250;
  private _loggerSend: Log;
  private _loggerSync: Log;
  private _loggerSleep: Log;

  private _noSleep: boolean;
  private _startTime?: number;
  private _startPts?: number;
  private _sync = true;
  private _syncStream?: BaseMediaStream;
  private _frameSendDeadlineExceededCount = 0;

  constructor(type: string, noSleep = false) {
    super({ objectMode: true, highWaterMark: 0 });
    this._loggerSend = new Log(`stream:${type}:send`);
    this._loggerSync = new Log(`stream:${type}:sync`);
    this._loggerSleep = new Log(`stream:${type}:sleep`);
    this._noSleep = noSleep;
  }

  get sync(): boolean {
    return this._sync;
  }
  set sync(val: boolean) {
    this._sync = val;
    if (val) this._loggerSync.debug("Sync enabled");
    else this._loggerSync.debug("Sync disabled");
  }
  get syncStream() {
    return this._syncStream;
  }
  set syncStream(stream: BaseMediaStream | undefined) {
    if (stream !== undefined && this === stream.syncStream)
      throw new Error("Cannot sync 2 streams with eachother");
    this._syncStream = stream;
  }
  get noSleep(): boolean {
    return this._noSleep;
  }
  set noSleep(val: boolean) {
    this._noSleep = val;
    if (!val) this.resetTimingCompensation();
  }
  get pts(): number | undefined {
    return this._pts;
  }
  get syncTolerance() {
    return this._syncTolerance;
  }
  set syncTolerance(n: number) {
    if (n < 0) return;
    this._syncTolerance = n;
  }
  protected async _sendFrame(
    _frame: Buffer,
    _frametime: number,
  ): Promise<void> {
    throw new Error("Not implemented");
  }
  private get ptsDelta() {
    if (this.pts !== undefined && this.syncStream?.pts !== undefined)
      return this.pts - this.syncStream.pts;
    return undefined;
  }
  private get isAhead() {
    const delta = this.ptsDelta;
    return (
      this.syncStream?.writableEnded === false &&
      delta !== undefined &&
      delta > this.syncTolerance
    );
  }
  private get isBehind() {
    const delta = this.ptsDelta;
    return (
      this.syncStream?.writableEnded === false &&
      delta !== undefined &&
      delta < -this.syncTolerance
    );
  }
  private resetTimingCompensation() {
    this._startTime = this._startPts = undefined;
  }
  async _write(
    frame: Packet,
    _: BufferEncoding,
    callback: (error?: Error | null) => void,
  ) {
    const { data, pts, duration, timeBase } = frame;
    if (!data) {
      frame.free();
      callback();
      return;
    }

    /*
     * AV_NOPTS_VALUE: packets without a presentation timestamp (e.g. the
     * first packets of an RTSP stream) are sent immediately, without pacing,
     * and without poisoning the timing compensation.
     */
    if (pts === AV_NOPTS_VALUE) {
      await this._sendFrame(Buffer.from(data), 0);
      frame.free();
      callback(null);
      return;
    }

    const frametime = (Number(duration) / timeBase.den) * timeBase.num * 1000;

    const start_sendFrame = performance.now();
    await this._sendFrame(Buffer.from(data), frametime);
    const end_sendFrame = performance.now();

    // A large pts jump means the source was seeked (or the timestamps
    // wrapped): the old pacing anchor no longer applies, so re-anchor
    // here instead of sleeping/skipping for the size of the jump.
    const prevPts = this._pts;
    this._pts = (Number(pts) / timeBase.den) * timeBase.num * 1000;
    this.emit("pts", this._pts);
    if (
      prevPts !== undefined &&
      Math.abs(this._pts - prevPts) > SEEK_JUMP_THRESHOLD_MS
    ) {
      this._loggerSync.debug(
        {
          stats: {
            pts: this._pts,
            pts_prev: prevPts,
          },
        },
        "Timestamp discontinuity detected. Re-syncing stream pacing",
      );
      this.resetTimingCompensation();
    }
    const sendTime = end_sendFrame - start_sendFrame;
    const ratio = sendTime / frametime;
    this._loggerSend.debug(
      {
        stats: {
          pts: this._pts,
          frame_size: data.length,
          duration: sendTime,
          frametime,
        },
      },
      `Frame sent in ${sendTime.toFixed(2)}ms (${(ratio * 100).toFixed(2)}% frametime)`,
    );
    if (ratio > 1) {
      this._frameSendDeadlineExceededCount++;
      if (this._frameSendDeadlineExceededCount > 10)
        this._loggerSend.warn(
          {
            frame_size: data.length,
            duration: sendTime,
            frametime,
          },
          `Frame takes too long to send (${(ratio * 100).toFixed(2)}% frametime)`,
        );
    } else {
      this._frameSendDeadlineExceededCount = 0;
    }

    this._startTime ??= start_sendFrame;
    this._startPts ??= this._pts;
    const sleep = Math.max(
      0,
      this._pts -
        this._startPts +
        frametime -
        (end_sendFrame - this._startTime),
    );
    if (this._noSleep || sleep === 0) {
      callback(null);
    } else if (this.sync && this.isBehind) {
      this._loggerSync.debug(
        {
          stats: {
            pts: this.pts,
            pts_other: this.syncStream?.pts,
          },
        },
        "Stream is behind. Not sleeping for this frame",
      );
      this.resetTimingCompensation();
      callback(null);
    } else if (this.sync && this.isAhead) {
      /*
       * Wait for the other stream to catch up, but at most for the amount we
       * are ahead of it: when flowing, it advances in real time, so it needs
       * at most `delta`ms. If it hasn't caught up by then it is starved (e.g.
       * the demuxer is blocked by backpressure on our own queue), and waiting
       * forever would deadlock the pipeline.
       */
      const delta = this.ptsDelta ?? 0;
      if (delta > MAX_SYNC_WAIT_MS) {
        /*
         * A gap this wide cannot be closed by waiting in real time: it would
         * take `delta`ms. It means the other stream's timestamps have moved
         * away wholesale (e.g. the other stream was seeked and is still
         * draining its stale pre-seek content, which runs minutes ahead of
         * ours). Waiting would freeze this stream into a multi-second
         * slideshow per frame, so race instead and let both streams re-anchor
         * on their post-seek frames.
         */
        this._loggerSync.debug(
          {
            stats: {
              pts: this.pts,
              pts_other: this.syncStream?.pts,
              pts_delta: delta,
            },
          },
          "Stream is far ahead. Not waiting for the other stream",
        );
        this.resetTimingCompensation();
        callback(null);
      } else {
        const deadline = performance.now() + delta;
        do {
          this._loggerSync.debug(
            {
              stats: {
                pts: this.pts,
                pts_other: this.syncStream?.pts,
                frametime,
              },
            },
            `Stream is ahead. Waiting for ${frametime}ms`,
          );
          await setTimeout(frametime);
          if (performance.now() >= deadline) break;
        } while (this.sync && this.isAhead);
        this.resetTimingCompensation();
        callback(null);
      }
    } else {
      this._loggerSleep.debug(
        {
          stats: {
            pts: this._pts,
            startPts: this._startPts,
            time: end_sendFrame,
            startTime: this._startTime,
            frametime,
          },
        },
        `Sleeping for ${sleep}ms`,
      );
      setTimeout(sleep).then(() => callback(null));
    }
    frame.free();
  }
  _destroy(
    error: Error | null,
    callback: (error?: Error | null) => void,
  ): void {
    super._destroy(error, callback);
    this.syncStream = undefined;
  }
}
